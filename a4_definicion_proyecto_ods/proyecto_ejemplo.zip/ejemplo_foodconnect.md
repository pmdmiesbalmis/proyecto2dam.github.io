---
title: 
    Ejemplo propuesta de proyecto ODS - FoodConnect
date: Jube 25th, 2025
export_on_save:
    puppeteer: true
puppeteer:
    scale: 1
    landscape: false
    format: "A4"
    printBackground: true
    margin:
        top: "1cm"
        right: "1cm"
        bottom: "2.5cm"
        left: "1cm"
    displayHeaderFooter: true
    headerTemplate: "&nbsp;"
    footerTemplate: "
        <span style=\"font-size: 9pt; display: flex;\">
            <span class=\"pageNumber\" style=\"margin-left: 1cm;\"></span>
            /
            <span class=\"totalPages\"></span>
            <span class=\"title\" style=\"margin-left: 1cm;\"></span>
            <span style=\"margin-left: 1cm;\">IES Doctor Balmis</span>
        </span>
                    "
---

# Propuesta de Proyecto: FoodConnect

## Título del Proyecto

**FoodConnect**: Conectando a la comunidad para reducir el desperdicio de alimentos.

![nombre](./assets/food_connect.png){ style="display:block;margin:0 auto;width:100%;max-width:500px;" }

## Datos del Equipo

* **Nombre del Proyecto:** FoodConnect
* **Equipo:** BalmisTech
* **Miembros del Equipo:**
  * María García López (Hacedora)
  * Juan Pérez Martínez (Analista)
  * Laura Sánchez Torres (Divergente)
  * Carlos Ruiz Navarro (Armonizador)
* **Curso:** 2º DAM - IES Doctor Balmis
* **Fecha de inicio:** Octubre 2025

## Alineación con los Objetivos de Desarrollo Sostenible (ODS)

Este proyecto se alinea directa y explícitamente con los siguientes Objetivos de Desarrollo Sostenible de las Naciones Unidas, tal como se requiere en la programación didáctica:

* **ODS 2: Hambre Cero:** Facilita la redistribución de excedentes de alimentos de comercios y particulares a personas que los necesitan, combatiendo el hambre a nivel local.  
* **ODS 12: Producción y Consumo Responsables:** Ataca directamente la meta 12.3, que busca reducir a la mitad el desperdicio de alimentos per cápita. La aplicación proporciona una plataforma para dar una segunda vida a los alimentos que de otro modo serían desechados.  
* **ODS 11: Ciudades y Comunidades Sostenibles:** Fomenta la creación de redes de apoyo locales y fortalece los lazos comunitarios al conectar a vecinos, ONGs y pequeños comercios con un objetivo común.

## Descripción del Problema

En nuestra comunidad, una gran cantidad de alimentos en perfecto estado es desechada diariamente por pequeños comercios (fruterías, panaderías, restaurantes) al final de su jornada, así como por particulares. Al mismo tiempo, existen familias y personas con dificultades para acceder a alimentos frescos y nutritivos. La desconexión entre quienes tienen un excedente y quienes lo necesitan es el principal obstáculo.

## Descripción de la Solución Propuesta

**FoodConnect** es una solución software multiplataforma diseñada para servir de puente entre donantes de alimentos y beneficiarios. El sistema constará de tres componentes principales, siguiendo la arquitectura definida en la programación:

1. **Aplicación Móvil para Clientes (Android con Kotlin y Jetpack Compose):** Será la herramienta principal para los usuarios (donantes y beneficiarios). Permitirá a los donantes publicar "cestas" de alimentos excedentes y a los beneficiarios buscarlas, reservarlas y coordinar su recogida.  
2. **Aplicación de Escritorio para Administradores (WPF con C\# y MVVM):** Una herramienta de back-office para que los administradores del sistema puedan gestionar usuarios (validar ONGs, bloquear usuarios con mal comportamiento), supervisar las publicaciones y obtener estadísticas básicas sobre el impacto de la plataforma.  
3. **Servicio Backend (API REST con Java):** El cerebro del sistema. Gestionará toda la lógica de negocio, la persistencia de datos en una base de datos MySQL, la autenticación de usuarios mediante Sesiones o JWT y la comunicación segura entre las aplicaciones cliente y de escritorio.

## Actores y Roles

* **Donante:** Cualquier particular, comercio u organización que desea ofrecer un excedente de alimentos.  
* **Beneficiario:** Cualquier persona u organización (ONG, comedor social) que necesita alimentos.  
* **Administrador:** Un superusuario que gestiona y modera la plataforma a través de la aplicación de escritorio.

## Arquitectura general

```puml {align="center", korki=true}
@startuml

/' 
    Visitar:
    https://plantuml-stdlib.github.io/C4-PlantUML/
    https://github.com/tupadr3/plantuml-icon-font-sprites

    Para más información sobre los diagramas C4 con plantUML
'/

!include  https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml

!include <tupadr3/devicons2/java_wordmark>
!include <tupadr3/devicons2/mysql_wordmark>
!include <tupadr3/font-awesome/mobile_phone>
!include <tupadr3/font-awesome/desktop>
!include <tupadr3/font-awesome/server>

skinparam backgroundColor Transparent
Scale 1
 
HIDE_STEREOTYPE()
LAYOUT_LEFT_RIGHT()

AddRelTag("blanco", $textColor="White", $lineColor="White")

Boundary(proyecto, "FoodConnect") { 
    Person(android_d, "App Android", "Donante", $sprite="mobile_phone")
    Person(android_b, "App Android", "Beneficiario", $sprite="mobile_phone")
    Person(desktop, "App WPF", "Administrador", $sprite="desktop")

    Container(azure, "Servidor", "", $sprite="server") {
        System(api, "API Rest", "", $sprite="java_wordmark")
        SystemDb(db, "BD", "", $sprite="mysql_wordmark")
    }

    Rel(android_d, api, "API Rest", "HTTP")
    Rel(android_b, api, "API Rest", "HTTP")
    Rel(desktop, api, "API Rest", "HTTP")
    Rel(api, db, "Conexión", "ORM", $tags="blanco")
}
@enduml
```

## Casos de Uso Principales

### Para Donantes (App Móvil)

| Caso de Uso                 | Descripción                                                                                                             | Prioridad |
| --------------------------- | ----------------------------------------------------------------------------------------------------------------------- | --------- |
| **Registro de Usuario**     | Permitir a donantes y beneficiarios registrarse en la aplicación móvil.                                                 | Alta      |
| **Publicar Cesta**          | Publicar una nueva "cesta de alimentos", especificando contenido, cantidad aproximada, ubicación y horario de recogida. | Alta      |
| **Subir Foto**              | Subir una foto de la cesta para mayor transparencia.                                                                    | Media     |
| **Ver Estado de Cestas**    | Ver el estado de sus cestas publicadas (disponible, reservada, recogida).                                               | Alta      |
| **Notificaciones**          | Recibir una notificación cuando su cesta sea reservada.                                                                 | Baja      |
| **Confirmar Recogida**      | Confirmar que la cesta ha sido recogida por el beneficiario.                                                            | Alta      |
| **Historial de Donaciones** | Consultar su historial de donaciones.                                                                                   | Media     |

### Para Beneficiarios (App Móvil)

| Caso de Uso                | Descripción                                                                              | Prioridad |
| -------------------------- | ---------------------------------------------------------------------------------------- | --------- |
| **Registro de Usuario**    | Permitir a donantes y beneficiarios registrarse en la aplicación móvil.                  | Alta      |
| **Buscar Cestas**          | Buscar cestas de alimentos disponibles cerca de su ubicación usando un mapa o una lista. | Alta      |
| **Filtrar Búsquedas**      | Filtrar búsquedas por tipo de alimento o distancia.                                      | Media     |
| **Ver Detalles de Cesta**  | Ver los detalles de una cesta y la información del donante.                              | Alta      |
| **Reservar Cesta**         | Reservar una cesta disponible.                                                           | Alta      |
| **Chat con Donante**       | Comunicarse con el donante a través de un chat simple para coordinar la recogida.        | Baja      |
| **Historial de Recogidas** | Consultar su historial de recogidas.                                                     | Media     |

### Para Administradores (App Escritorio)

| Caso de Uso                    | Descripción                                                                                       | Prioridad |
| ------------------------------ | ------------------------------------------------------------------------------------------------- | --------- |
| **Inicio de Sesión Seguro**    | Permitir a los administradores iniciar sesión de forma segura.                                    | Alta      |
| **Gestión de Usuarios**        | Ver un listado de todos los usuarios (donantes y beneficiarios).                                  | Alta      |
| **Validar ONGs**               | Validar el registro de nuevas ONGs o comedores sociales.                                          | Media     |
| **Bloquear/Eliminar Usuarios** | Bloquear o eliminar usuarios que incumplan las normas de la comunidad.                            | Alta      |
| **Gestión de Publicaciones**   | Visualizar y eliminar publicaciones que sean inapropiadas.                                        | Media     |
| **Ver Estadísticas**           | Ver estadísticas básicas (ej: nº dse cestas donadas en la última semana, nº de usuarios activos). | Baja      |

## Riesgos y mitigación

| Riesgo                  | Mitigación                                                                   |
| ----------------------- | ---------------------------------------------------------------------------- |
| Chat en tiempo real     | Requiere del uso de FLows y corrutina en Kotlin + Firebase                   |
| Mapas y geolocalización | Uso de Google Maps SDK (API Key) y componentes específico de Maps en compose |
| Notificaciones push     | Uso de Firebase Cloud Messaging (FCM)                                        |
| Complejidad JWT         | Taller extra + plantilla base o usar sesiones                                |
| Retraso en integración  | Feature-flags para desactivar parte no crítica                               |
| Scope creep             | Definición clara del **Producto Mínimo Viable** (MVP) priorizando el backlog |
| Falta de experiencia    | Uso de IA para generación de código y resolución de dudas                    |
| Falta de compromiso     | Reuniones semanales de seguimiento y revisión del progreso                   |
| Conflictos en equipo    | Roles claros y comunicación abierta                                          |

## Planificación aproximada Sprints por quincena

La planificación temporal sigue rigurosamente el marco establecido en la programación didáctica del módulo, dividiéndose en tres etapas: fase preparatoria inicial (semanas 1-8), fase de desarrollo colaborativo en equipo mediante **SCRUM** (Sprints 1 al 8, semanas 9 a 24) y fase de **desarrollo individual durante la Formación en Empresa (FE)** (semanas 25 a 32), culminando con la presentación final.

### Calendario de Sprints y Fases de Desarrollo

| Sprint | Semanas | Fechas | Objetivo Principal | Entregable Clave (FoodConnect) |
| :---: | :---: | :---: | :--- | :--- |
| **1** | 9-10 | 09 nov<br/>20 nov | Prototipado UI/UX | Prototipos navegables en Figma/Penpot de la App móvil (vistas de donante y beneficiario) y de la App de escritorio para administración. |
| **2** | 11-12 | 23 nov<br/>04 dic<br/>*(**1ª Ev**)* | Modelo de dominio en C#, transpilación y mocks con IA | Clases de dominio C# (`Usuario`, `Donante`, `Beneficiario`, `Cesta`, `Reserva`, `Ubicacion`), transpiladas con IA a Kotlin y Java, junto con datasets sintéticos JSON para pruebas desacopladas. |
| **3** | 13-14 | 07 dic<br/>18 dic | Frontend Móvil (Android + MVI): UI | Implementación de pantallas en Android (Jetpack Compose + Material 3) para la App de donantes y beneficiarios, con navegación visual y previews. |
| **4** | 15-16 | 07 ene<br/>15 ene | Frontend Móvil: Lógica funcional | Sprint Planning e integración de ViewModels (arquitectura MVI), lógica de interacción y consumo de repositorios mock de cestas y reservas. |
| **5** | 17-18 | 18 ene<br/>29 ene | Frontend Escritorio (WPF + MVVM): UI | Implementación de vistas XAML con WPF para la gestión administrativa de FoodConnect (listado de usuarios, moderación de publicaciones). |
| **6** | 19-20 | 01 feb<br/>12 feb | Frontend Escritorio: Lógica funcional | Implementación de ViewModels (patrón MVVM con CommunityToolkit), comandos e interacción conectando con datos mock de administración. |
| **7** | 21-22 | 15 feb<br/>26 feb<br/>*(**2ª Ev**)* | Backend: API REST (CRUD) | Definición de entidades ORM y esquema MySQL. Endpoints CRUD completos para gestión de usuarios, cestas de alimentos y reservas. |
| **8** | 23-24 | 01 mar<br/>12 mar | Backend: API REST (Lógica de negocio) | Servicios con reglas de negocio (disponibilidad de stock, control de caducidad, bloqueo de solapamientos), DTOs y manejo centralizado de excepciones. |
| **FE** | 25-28 | 15 mar<br/>21 may | Fase Formación en Empresa: Trabajo Individual | Implementación de funcionalidades individuales avanzadas sin Scrum (evaluación con rúbrica individual por alumno). |
| **Fin** | 33-34 | 24 may<br/>04 jun | Cierre, entrega y defensa | Memoria técnica final en Markdown (`PROYECTO.md` y `DISENO.md`), vídeo demostrativo del producto (2-3 min) y defensa oral del proyecto. |

### Reparto de Funcionalidades Individuales (Fase FE)

Durante la estancia en empresa (FE), cada miembro de BalmisTech desarrolla de forma autónoma una de las propuestas excluyentes del catálogo oficial:

1. **María García López (Hacedora) - Integración Full-Stack Android:**
   - Conexión de la App Android Jetpack Compose a la API REST real mediante Retrofit y Corrutinas, persistiendo el token JWT y completando el ciclo real de donación y reserva.
2. **Juan Pérez Martínez (Analista) - Seguridad, Roles y Documentación OpenAPI:**
   - Implementación en la API REST de endpoints de registro y login con JWT, autenticación stateless, control de acceso por roles (`DONANTE`, `BENEFICIARIO`, `ADMIN`) y documentación interactiva con Swagger UI.
3. **Laura Sánchez Torres (Divergente) - Integración Full-Stack Escritorio:**
   - Conexión de la App WPF a la API REST de forma segura mediante `HttpClient` y JWT, permitiendo la moderación de publicaciones y validación de ONGs en tiempo real contra el servidor.
4. **Carlos Ruiz Navarro (Armonizador) - Ampliación Funcional Full-Stack (Geolocalización):**
   - Integración de Google Maps SDK en la App Android para búsqueda visual de cestas cercanas por radio de distancia y desarrollo de endpoints backend para filtrado geoespacial.

## Organización repositorio

```txt
https://github.com/BalmisTech/FoodConnect
├── docs/
│   ├── PROYECTO.md      ← visión, ODS, casos de uso
│   ├── DISENO.md        ← modelo, decisiones arquitectónicas
│   └── DIARIO.md        ← seguimiento semanal individual
├── backend/
├── frontend-wpf/
└── frontend-android/
```