---
title: 
    Ejemplo propuesta de proyecto ODS - FoodConnect
date: Jube 25th, 2025
export_on_save:
    puppeteer: true
puppeteer:
    scale: 1
    landscape: false
    format: "A4"
    printBackground: true
    margin:
        top: "1cm"
        right: "1cm"
        bottom: "2.5cm"
        left: "1cm"
    displayHeaderFooter: true
    headerTemplate: "&nbsp;"
    footerTemplate: "
        <span style=\"font-size: 9pt; display: flex;\">
            <span class=\"pageNumber\" style=\"margin-left: 1cm;\"></span>
            /
            <span class=\"totalPages\"></span>
            <span class=\"title\" style=\"margin-left: 1cm;\"></span>
            <span style=\"margin-left: 1cm;\">IES Doctor Balmis</span>
        </span>
                    "
---

# Propuesta de Proyecto: FoodConnect

## Título del Proyecto

**FoodConnect**: Conectando a la comunidad para reducir el desperdicio de alimentos.

![nombre](./assets/food_connect.png){ style="display:block;margin:0 auto;width:100%;max-width:500px;" }

## Datos del Equipo

* **Nombre del Proyecto:** FoodConnect
* **Equipo:** BalmisTech
* **Miembros del Equipo:**
  * María García López (Hacedora)
  * Juan Pérez Martínez (Analista)
  * Laura Sánchez Torres (Divergente)
  * Carlos Ruiz Navarro (Armonizador)
* **Curso:** 2º DAM - IES Doctor Balmis
* **Fecha de inicio:** Octubre 2025

## Alineación con los Objetivos de Desarrollo Sostenible (ODS)

Este proyecto se alinea directa y explícitamente con los siguientes Objetivos de Desarrollo Sostenible de las Naciones Unidas, tal como se requiere en la programación didáctica:

* **ODS 2: Hambre Cero:** Facilita la redistribución de excedentes de alimentos de comercios y particulares a personas que los necesitan, combatiendo el hambre a nivel local.  
* **ODS 12: Producción y Consumo Responsables:** Ataca directamente la meta 12.3, que busca reducir a la mitad el desperdicio de alimentos per cápita. La aplicación proporciona una plataforma para dar una segunda vida a los alimentos que de otro modo serían desechados.  
* **ODS 11: Ciudades y Comunidades Sostenibles:** Fomenta la creación de redes de apoyo locales y fortalece los lazos comunitarios al conectar a vecinos, ONGs y pequeños comercios con un objetivo común.

## Descripción del Problema

En nuestra comunidad, una gran cantidad de alimentos en perfecto estado es desechada diariamente por pequeños comercios (fruterías, panaderías, restaurantes) al final de su jornada, así como por particulares. Al mismo tiempo, existen familias y personas con dificultades para acceder a alimentos frescos y nutritivos. La desconexión entre quienes tienen un excedente y quienes lo necesitan es el principal obstáculo.

## Descripción de la Solución Propuesta

**FoodConnect** es una solución software multiplataforma diseñada para servir de puente entre donantes de alimentos y beneficiarios. El sistema constará de tres componentes principales, siguiendo la arquitectura definida en la programación:

1. **Aplicación Móvil para Clientes (Android con Kotlin y Jetpack Compose):** Será la herramienta principal para los usuarios (donantes y beneficiarios). Permitirá a los donantes publicar "cestas" de alimentos excedentes y a los beneficiarios buscarlas, reservarlas y coordinar su recogida.  
2. **Aplicación de Escritorio para Administradores (WPF con C\# y MVVM):** Una herramienta de back-office para que los administradores del sistema puedan gestionar usuarios (validar ONGs, bloquear usuarios con mal comportamiento), supervisar las publicaciones y obtener estadísticas básicas sobre el impacto de la plataforma.  
3. **Servicio Backend (API REST con Java):** El cerebro del sistema. Gestionará toda la lógica de negocio, la persistencia de datos en una base de datos MySQL, la autenticación de usuarios mediante Sesiones o JWT y la comunicación segura entre las aplicaciones cliente y de escritorio.

## Actores y Roles

* **Donante:** Cualquier particular, comercio u organización que desea ofrecer un excedente de alimentos.  
* **Beneficiario:** Cualquier persona u organización (ONG, comedor social) que necesita alimentos.  
* **Administrador:** Un superusuario que gestiona y modera la plataforma a través de la aplicación de escritorio.

## Arquitectura general

```puml {align="center", korki=true}
@startuml

/' 
    Visitar:
    https://plantuml-stdlib.github.io/C4-PlantUML/
    https://github.com/tupadr3/plantuml-icon-font-sprites

    Para más información sobre los diagramas C4 con plantUML
'/

!include  https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml

!include <tupadr3/devicons2/java_wordmark>
!include <tupadr3/devicons2/mysql_wordmark>
!include <tupadr3/font-awesome/mobile_phone>
!include <tupadr3/font-awesome/desktop>
!include <tupadr3/font-awesome/server>

skinparam backgroundColor Transparent
Scale 1
 
HIDE_STEREOTYPE()
LAYOUT_LEFT_RIGHT()

AddRelTag("blanco", $textColor="White", $lineColor="White")

Boundary(proyecto, "FoodConnect") { 
    Person(android_d, "App Android", "Donante", $sprite="mobile_phone")
    Person(android_b, "App Android", "Beneficiario", $sprite="mobile_phone")
    Person(desktop, "App WPF", "Administrador", $sprite="desktop")

    Container(azure, "Servidor", "", $sprite="server") {
        System(api, "API Rest", "", $sprite="java_wordmark")
        SystemDb(db, "BD", "", $sprite="mysql_wordmark")
    }

    Rel(android_d, api, "API Rest", "HTTP")
    Rel(android_b, api, "API Rest", "HTTP")
    Rel(desktop, api, "API Rest", "HTTP")
    Rel(api, db, "Conexión", "ORM", $tags="blanco")
}
@enduml
```

## Casos de Uso Principales

### Para Donantes (App Móvil)

| Caso de Uso                 | Descripción                                                                                                             | Prioridad |
| --------------------------- | ----------------------------------------------------------------------------------------------------------------------- | --------- |
| **Registro de Usuario**     | Permitir a donantes y beneficiarios registrarse en la aplicación móvil.                                                 | Alta      |
| **Publicar Cesta**          | Publicar una nueva "cesta de alimentos", especificando contenido, cantidad aproximada, ubicación y horario de recogida. | Alta      |
| **Subir Foto**              | Subir una foto de la cesta para mayor transparencia.                                                                    | Media     |
| **Ver Estado de Cestas**    | Ver el estado de sus cestas publicadas (disponible, reservada, recogida).                                               | Alta      |
| **Notificaciones**          | Recibir una notificación cuando su cesta sea reservada.                                                                 | Baja      |
| **Confirmar Recogida**      | Confirmar que la cesta ha sido recogida por el beneficiario.                                                            | Alta      |
| **Historial de Donaciones** | Consultar su historial de donaciones.                                                                                   | Media     |

### Para Beneficiarios (App Móvil)

| Caso de Uso                | Descripción                                                                              | Prioridad |
| -------------------------- | ---------------------------------------------------------------------------------------- | --------- |
| **Registro de Usuario**    | Permitir a donantes y beneficiarios registrarse en la aplicación móvil.                  | Alta      |
| **Buscar Cestas**          | Buscar cestas de alimentos disponibles cerca de su ubicación usando un mapa o una lista. | Alta      |
| **Filtrar Búsquedas**      | Filtrar búsquedas por tipo de alimento o distancia.                                      | Media     |
| **Ver Detalles de Cesta**  | Ver los detalles de una cesta y la información del donante.                              | Alta      |
| **Reservar Cesta**         | Reservar una cesta disponible.                                                           | Alta      |
| **Chat con Donante**       | Comunicarse con el donante a través de un chat simple para coordinar la recogida.        | Baja      |
| **Historial de Recogidas** | Consultar su historial de recogidas.                                                     | Media     |

### Para Administradores (App Escritorio)

| Caso de Uso                    | Descripción                                                                                       | Prioridad |
| ------------------------------ | ------------------------------------------------------------------------------------------------- | --------- |
| **Inicio de Sesión Seguro**    | Permitir a los administradores iniciar sesión de forma segura.                                    | Alta      |
| **Gestión de Usuarios**        | Ver un listado de todos los usuarios (donantes y beneficiarios).                                  | Alta      |
| **Validar ONGs**               | Validar el registro de nuevas ONGs o comedores sociales.                                          | Media     |
| **Bloquear/Eliminar Usuarios** | Bloquear o eliminar usuarios que incumplan las normas de la comunidad.                            | Alta      |
| **Gestión de Publicaciones**   | Visualizar y eliminar publicaciones que sean inapropiadas.                                        | Media     |
| **Ver Estadísticas**           | Ver estadísticas básicas (ej: nº dse cestas donadas en la última semana, nº de usuarios activos). | Baja      |

## Riesgos y mitigación

| Riesgo                  | Mitigación                                                                   |
| ----------------------- | ---------------------------------------------------------------------------- |
| Chat en tiempo real     | Requiere del uso de FLows y corrutina en Kotlin + Firebase                   |
| Mapas y geolocalización | Uso de Google Maps SDK (API Key) y componentes específico de Maps en compose |
| Notificaciones push     | Uso de Firebase Cloud Messaging (FCM)                                        |
| Complejidad JWT         | Taller extra + plantilla base o usar sesiones                                |
| Retraso en integración  | Feature-flags para desactivar parte no crítica                               |
| Scope creep             | Definición clara del **Producto Mínimo Viable** (MVP) priorizando el backlog |
| Falta de experiencia    | Uso de IA para generación de código y resolución de dudas                    |
| Falta de compromiso     | Reuniones semanales de seguimiento y revisión del progreso                   |
| Conflictos en equipo    | Roles claros y comunicación abierta                                          |

## Planificación aproximada Sprints por quincena

| Sprint | Semanas | Fecha fin | Entregable clave                                                  |
| ------ | ------- | --------- | ----------------------------------------------------------------- |
| 1      | 7-8     | 31 oct    | Modelo de dominio Java + diagramas                                |
| 2      | 9-10    | 14 nov    | Clases transpiladas a C#/Kotlin + mocks con IA                    |
| 3      | 11-12   | 28 nov    | Prototipos UI/UX Stitch/Figma (Material 3 & XAML)                 |
| 4      | 13-14   | 12 dic    | App WPF navegable con datos mock (**1ª evaluación**)              |
| 5      | 15-16   | 16 ene    | App Android navegable con estados mock                            |
| 6      | 17-18   | 30 ene    | Lógica de negocio en WPF (MVVM)                                   |
| 7      | 19-20   | 13 feb    | Lógica de negocio en Android (MVI)                                |
| 8      | 21-22   | 27 feb    | API REST CRUD + BBDD MySQL (**2ª evaluación**)                    |
| 9      | 23-24   | 13 mar    | Servicios de negocio + DTOs + excepciones                         |
| 10     | 25-26   | 27 mar    | Seguridad: registro/login JWT + Autorización por roles            |
| 11     | 27-28   | 08 may    | Documentación API con Swagger e Integración full-stack escritorio |
| 12     | 29-30   | 22 may    | Integración full-stack Andrioid                                   |
| 13     | 31-32   | 05 jun    | Memoria final, vídeo 2 min, presentación oral                     |

## Organización repositorio

```txt
https://github.com/BalmisTech/FoodConnect
├── docs/
│   ├── PROYECTO.md      ← visión, ODS, casos de uso
│   ├── DISENO.md        ← modelo, decisiones arquitectónicas
│   └── DIARIO.md        ← seguimiento semanal individual
├── backend/
├── frontend-wpf/
└── frontend-android/
```